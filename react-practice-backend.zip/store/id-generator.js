var id = 0;

module.exports = {
  getNext: function () {
    return ++id;
  }
}
